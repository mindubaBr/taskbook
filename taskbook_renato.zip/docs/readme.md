## Taskbook Translated Documentation

- [简体中文 - Simplified Chinese](https://github.com/klauscfhq/taskbook/blob/master/docs/readme.ZH.md) by [@chinanf-boy](https://github.com/chinanf-boy), [@rosuH](https://github.com/rosuH)

- [Русский - Russian](https://github.com/klauscfhq/taskbook/blob/master/docs/readme.RU.md) by [@zhadyrassyn](https://github.com/zhadyrassyn), [@gebeto](https://github.com/gebeto)

## Contributing

Visit the [contributing guidelines](https://github.com/klauscfhq/taskbook/blob/master/contributing.md#translating-documentation) to learn more on how to get involved in the translating process.

## Thanks

Tons of thank you to the amazing people that help out with the creation and maintenance of the translations! Your contributions make Taskbook available to everyone around the world! ❤️

